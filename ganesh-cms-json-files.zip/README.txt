GANESH DIGITAL STUDIO - STARTER CMS JSON FILES

Copy the content/ folder into the ROOT of your GitHub repository.

Files included:
- content/homepage.json
- content/about.json
- content/portfolio/wedding-1.json
- content/reviews/review-1.json

IMPORTANT:
1. The homepage and about JSON files require matching file entries in .pages.yml.
2. Portfolio and review files match the collection pattern from the earlier configuration.
3. Replace placeholder text and image paths with your real content.
4. Keep featured=false until each portfolio item/review is ready to display.
5. These JSON files alone do not make the website read CMS content. The site's JavaScript must fetch and render these files.
